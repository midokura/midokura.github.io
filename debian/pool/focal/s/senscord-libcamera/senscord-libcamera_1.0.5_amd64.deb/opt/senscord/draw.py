import os
import time
import cv2
import glob
import json
import sys
if len(sys.argv) > 1:
    BASE_DIR = sys.argv[1]
else:
    BASE_DIR = '.'

person_enhance = False
if len(sys.argv) > 2:
    person_enhance = sys.argv[2]

IMAGE_DIR = os.path.join(BASE_DIR, 'image')
INFER_DIR = os.path.join(BASE_DIR, 'inference')

def find_closest_txt(image_filename):
    # Extract the timestamp part from the image filename
    basename = os.path.splitext(os.path.basename(image_filename))[0]
    img_ts = int(basename)
    txt_files = glob.glob(os.path.join(INFER_DIR, '*.txt'))
    min_diff = float('inf')
    closest_txt = None
    for txt in txt_files:
        txt_basename = os.path.splitext(os.path.basename(txt))[0]
        try:
            txt_ts = int(txt_basename)
            diff = abs(img_ts - txt_ts)
            if diff < min_diff:
                min_diff = diff
                closest_txt = txt
        except ValueError:
            continue
    return closest_txt

def draw_boxes(image, txt_file, fill_class0=False):
    if not txt_file or not os.path.exists(txt_file):
        return image
    h, w = image.shape[:2]
    with open(txt_file, 'r') as f:
        try:
            data = json.load(f)
            if "Inferences" in data:
                for inference in data["Inferences"]:
                    if "O" in inference:
                        for obj in inference["O"]:
                            bbox = obj.get("bounding_box")
                            score = obj.get("score")
                            class_id = obj.get("class_id")
                            # Assign color based on class_id
                            if class_id is not None:
                                color = (
                                    (int(class_id) * 37) % 256,
                                    (int(class_id) * 67) % 256,
                                    (int(class_id) * 97) % 256
                                )
                            else:
                                color = (0, 0, 255)
                            if bbox:
                                left = int(bbox.get("left", 0))
                                top = int(bbox.get("top", 0))
                                right = int(bbox.get("right", 0))
                                bottom = int(bbox.get("bottom", 0))
                                if fill_class0 and class_id == 0:
                                    cv2.rectangle(image, (left, top), (right, bottom), (0, 0, 255), -1)
                                else:
                                    cv2.rectangle(image, (left, top), (right, bottom), color, 2)
                                if class_id is not None:
                                    cv2.putText(
                                        image,
                                        str(class_id),
                                        (left, top + 10),
                                        cv2.FONT_HERSHEY_SIMPLEX,
                                        0.4,
                                        color,
                                        1
                                    )
                                    if score is not None:
                                        cv2.putText(
                                            image,
                                            f"{int(score * 100):02d}%",
                                            (left, top + 20),
                                            cv2.FONT_HERSHEY_SIMPLEX,
                                            0.4,
                                            color,
                                            1
                                        )
        except json.JSONDecodeError:
            # fallback to YOLO format if not JSON
            f.seek(0)
            for line in f:
                parts = line.strip().split()
                if len(parts) != 5:
                    continue
                class_id, x, y, bw, bh = map(float, parts)
                x1 = int((x - bw/2) * w)
                y1 = int((y - bh/2) * h)
                x2 = int((x + bw/2) * w)
                y2 = int((y + bh/2) * h)
                if fill_class0 and int(class_id) == 0:
                    cv2.rectangle(image, (x1, y1), (x2, y2), (0, 0, 255), -1)
                else:
                    cv2.rectangle(image, (x1, y1), (x2, y2), (0,0,255), 2)
    return image

def maintain_max_files(directory, pattern, max_files=100):
    files = sorted(glob.glob(os.path.join(directory, pattern)))
    if len(files) > max_files:
        for f in files[:len(files) - max_files]:
            try:
                os.remove(f)
            except Exception:
                pass

def main():
    last_shown_jpg = None
    last_shown_txt = None
    latest_jpg = None
    latest_txt = None
    maginification = 1.5
    defalutimg_size = 300

    while True:
        # Limit the number of files to keep
        maintain_max_files(IMAGE_DIR, '*.jpg', 100)
        maintain_max_files(INFER_DIR, '*.txt', 100)

        jpg_files = sorted(glob.glob(os.path.join(IMAGE_DIR, '*.jpg')))
        txt_files = sorted(glob.glob(os.path.join(INFER_DIR, '*.txt')))
        if jpg_files:
            latest_jpg = jpg_files[-1]
            if latest_jpg != last_shown_jpg:
                img = cv2.imread(latest_jpg)
                if img is not None:
                    latest_txt = find_closest_txt(latest_jpg)
                    img = draw_boxes(img, latest_txt)
                    # Resize window to 1.5x image size
                    h, w = img.shape[:2]
                    win_w, win_h = int(w * maginification), int(h * maginification)
                    resized_img = cv2.resize(img, (win_w, win_h))
                    cv2.imshow('Image', resized_img)
                    cv2.setWindowTitle('Image', os.path.basename(latest_jpg))
                    last_shown_jpg = latest_jpg
                    last_shown_txt = latest_txt
            else: #if image is not updated
                if txt_files:
                    latest_txt = txt_files[-1]
                    if last_shown_txt != latest_txt:# if inference file is updated
                        # print("image is not updated, but inference file is updated")
                        # print(f"latest_txt: {latest_txt}")
                        if latest_txt and os.path.exists(latest_txt):
                            with open(latest_txt, 'r') as f:
                                try:
                                    data = json.load(f)
                                    if "Inferences" in data:
                                        for inference in data["Inferences"]:
                                            if "O" in inference and isinstance(inference["O"], list) and len(inference["O"]) == 0:
                                                continue
                                            #print(inference)
                                except json.JSONDecodeError:
                                    print(f.read())

                        if resized_img is not None:
                            black_img = resized_img.copy()
                            black_img[:] = 0
                        else:
                            black_img = cv2.cvtColor(cv2.UMat(defalutimg_size*resized_img, defalutimg_size*resized_img, cv2.CV_8UC3), cv2.COLOR_BGR2RGB).get()
                            black_img[:] = 0
                        black_img = draw_boxes(black_img, latest_txt, fill_class0=person_enhance)
                        cv2.imshow('Image', black_img)
                        cv2.setWindowTitle('Image', 'No Input Tensor')
                        last_shown_txt = latest_txt



        key = cv2.waitKey(100) & 0xFF
        if key == 27:  # ESC key
            cv2.destroyAllWindows()
            return
        

if __name__ == '__main__':
    main()
