from __future__ import annotations
import numpy
import typing
__all__ = ['AI_MODEL_BUNDLE_ID_SIZE', 'Aborted', 'AlreadyExists', 'Base64', 'Cancelled', 'DataExportDataType', 'DataExportResult', 'DataLoss', 'DataTooLarge', 'DeadlineExceeded', 'Denied', 'ERROR', 'EdgeAppError', 'EdgeAppLibSensorStatusParam', 'Enqueued', 'FailedPrecondition', 'Internal', 'InvalidArgument', 'InvalidParam', 'Json', 'MESSAGE', 'Metadata', 'NotFound', 'Ok', 'OutOfRange', 'PermissionDenied', 'Raw', 'ResourceExhausted', 'ResponseCode', 'SUCCESS', 'SendDataType', 'SensorAiModelBundleId', 'SensorChannel', 'SensorFrame', 'SensorImageCrop', 'SensorStream', 'TRACE', 'Timeout', 'Unauthenticated', 'Unavailable', 'Unimplemented', 'Uninitialized', 'Unknown', 'format_timestamp', 'get_file_suffix', 'get_last_error_string', 'get_port_settings', 'get_workspace_directory', 'run_sm', 'send_file', 'send_input_tensor', 'send_metadata', 'send_state', 'send_telemetry', 'stream']
class DataExportDataType:
    """
    Members:
    
      Raw
    
      Metadata
    """
    Metadata: typing.ClassVar[DataExportDataType]  # value = <DataExportDataType.Metadata: 1>
    Raw: typing.ClassVar[DataExportDataType]  # value = <DataExportDataType.Raw: 0>
    __members__: typing.ClassVar[dict[str, DataExportDataType]]  # value = {'Raw': <DataExportDataType.Raw: 0>, 'Metadata': <DataExportDataType.Metadata: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class DataExportResult:
    """
    Members:
    
      SUCCESS
    
      ERROR
    
      Timeout
    
      InvalidParam
    
      DataTooLarge
    
      Denied
    
      Enqueued
    
      Uninitialized
    """
    DataTooLarge: typing.ClassVar[DataExportResult]  # value = <DataExportResult.DataTooLarge: 4>
    Denied: typing.ClassVar[DataExportResult]  # value = <DataExportResult.Denied: 5>
    ERROR: typing.ClassVar[DataExportResult]  # value = <DataExportResult.ERROR: 1>
    Enqueued: typing.ClassVar[DataExportResult]  # value = <DataExportResult.Enqueued: 6>
    InvalidParam: typing.ClassVar[DataExportResult]  # value = <DataExportResult.InvalidParam: 3>
    SUCCESS: typing.ClassVar[DataExportResult]  # value = <DataExportResult.SUCCESS: 0>
    Timeout: typing.ClassVar[DataExportResult]  # value = <DataExportResult.Timeout: 2>
    Uninitialized: typing.ClassVar[DataExportResult]  # value = <DataExportResult.Uninitialized: 7>
    __members__: typing.ClassVar[dict[str, DataExportResult]]  # value = {'SUCCESS': <DataExportResult.SUCCESS: 0>, 'ERROR': <DataExportResult.ERROR: 1>, 'Timeout': <DataExportResult.Timeout: 2>, 'InvalidParam': <DataExportResult.InvalidParam: 3>, 'DataTooLarge': <DataExportResult.DataTooLarge: 4>, 'Denied': <DataExportResult.Denied: 5>, 'Enqueued': <DataExportResult.Enqueued: 6>, 'Uninitialized': <DataExportResult.Uninitialized: 7>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class EdgeAppError(Exception):
    pass
class EdgeAppLibSensorStatusParam:
    """
    Members:
    
      MESSAGE
    
      TRACE
    """
    MESSAGE: typing.ClassVar[EdgeAppLibSensorStatusParam]  # value = <EdgeAppLibSensorStatusParam.MESSAGE: 0>
    TRACE: typing.ClassVar[EdgeAppLibSensorStatusParam]  # value = <EdgeAppLibSensorStatusParam.TRACE: 2>
    __members__: typing.ClassVar[dict[str, EdgeAppLibSensorStatusParam]]  # value = {'MESSAGE': <EdgeAppLibSensorStatusParam.MESSAGE: 0>, 'TRACE': <EdgeAppLibSensorStatusParam.TRACE: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ResponseCode:
    """
    Members:
    
      Ok
    
      Cancelled
    
      Unknown
    
      InvalidArgument
    
      DeadlineExceeded
    
      NotFound
    
      AlreadyExists
    
      PermissionDenied
    
      ResourceExhausted
    
      FailedPrecondition
    
      Aborted
    
      OutOfRange
    
      Unimplemented
    
      Internal
    
      Unavailable
    
      DataLoss
    
      Unauthenticated
    """
    Aborted: typing.ClassVar[ResponseCode]  # value = <ResponseCode.Aborted: 10>
    AlreadyExists: typing.ClassVar[ResponseCode]  # value = <ResponseCode.AlreadyExists: 6>
    Cancelled: typing.ClassVar[ResponseCode]  # value = <ResponseCode.Cancelled: 1>
    DataLoss: typing.ClassVar[ResponseCode]  # value = <ResponseCode.DataLoss: 15>
    DeadlineExceeded: typing.ClassVar[ResponseCode]  # value = <ResponseCode.DeadlineExceeded: 4>
    FailedPrecondition: typing.ClassVar[ResponseCode]  # value = <ResponseCode.FailedPrecondition: 9>
    Internal: typing.ClassVar[ResponseCode]  # value = <ResponseCode.Internal: 13>
    InvalidArgument: typing.ClassVar[ResponseCode]  # value = <ResponseCode.InvalidArgument: 3>
    NotFound: typing.ClassVar[ResponseCode]  # value = <ResponseCode.NotFound: 5>
    Ok: typing.ClassVar[ResponseCode]  # value = <ResponseCode.Ok: 0>
    OutOfRange: typing.ClassVar[ResponseCode]  # value = <ResponseCode.OutOfRange: 11>
    PermissionDenied: typing.ClassVar[ResponseCode]  # value = <ResponseCode.PermissionDenied: 7>
    ResourceExhausted: typing.ClassVar[ResponseCode]  # value = <ResponseCode.ResourceExhausted: 8>
    Unauthenticated: typing.ClassVar[ResponseCode]  # value = <ResponseCode.Unauthenticated: 16>
    Unavailable: typing.ClassVar[ResponseCode]  # value = <ResponseCode.Unavailable: 14>
    Unimplemented: typing.ClassVar[ResponseCode]  # value = <ResponseCode.Unimplemented: 12>
    Unknown: typing.ClassVar[ResponseCode]  # value = <ResponseCode.Unknown: 2>
    __members__: typing.ClassVar[dict[str, ResponseCode]]  # value = {'Ok': <ResponseCode.Ok: 0>, 'Cancelled': <ResponseCode.Cancelled: 1>, 'Unknown': <ResponseCode.Unknown: 2>, 'InvalidArgument': <ResponseCode.InvalidArgument: 3>, 'DeadlineExceeded': <ResponseCode.DeadlineExceeded: 4>, 'NotFound': <ResponseCode.NotFound: 5>, 'AlreadyExists': <ResponseCode.AlreadyExists: 6>, 'PermissionDenied': <ResponseCode.PermissionDenied: 7>, 'ResourceExhausted': <ResponseCode.ResourceExhausted: 8>, 'FailedPrecondition': <ResponseCode.FailedPrecondition: 9>, 'Aborted': <ResponseCode.Aborted: 10>, 'OutOfRange': <ResponseCode.OutOfRange: 11>, 'Unimplemented': <ResponseCode.Unimplemented: 12>, 'Internal': <ResponseCode.Internal: 13>, 'Unavailable': <ResponseCode.Unavailable: 14>, 'DataLoss': <ResponseCode.DataLoss: 15>, 'Unauthenticated': <ResponseCode.Unauthenticated: 16>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SendDataType:
    """
    Members:
    
      Base64
    
      Json
    """
    Base64: typing.ClassVar[SendDataType]  # value = <SendDataType.Base64: 0>
    Json: typing.ClassVar[SendDataType]  # value = <SendDataType.Json: 1>
    __members__: typing.ClassVar[dict[str, SendDataType]]  # value = {'Base64': <SendDataType.Base64: 0>, 'Json': <SendDataType.Json: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SensorAiModelBundleId:
    id: str
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
class SensorChannel:
    def __repr__(self) -> str:
        ...
    @property
    def data(self) -> numpy.ndarray[numpy.float32]:
        """
        Access the channel data as a typed numpy array.
        """
    @property
    def handle(self) -> int:
        ...
    @property
    def raw_data(self) -> memoryview:
        """
        Access the channel data as a raw memory view.
        """
class SensorFrame:
    def __repr__(self) -> str:
        ...
    def get_channel(self, arg0: int) -> SensorChannel:
        ...
    def get_inputs(self) -> tuple[numpy.ndarray[numpy.uint8], int]:
        ...
    def get_outputs(self) -> list[numpy.ndarray[numpy.float32]]:
        ...
    @property
    def handle(self) -> int:
        ...
class SensorImageCrop:
    height: int
    left: int
    top: int
    width: int
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
class SensorStream:
    ai_model_bundle_id: SensorAiModelBundleId
    image_crop: SensorImageCrop
    def __repr__(self) -> str:
        ...
    def get_frame(self, timeout_msec: int) -> SensorFrame:
        """
                Get sensor frame. Returns the oldest unobtained handle of frame.
        
                :param timeout_msec: timeout value (0: timeout immediately, -1: not timeout infinitely)
                :raises EdgeAppError:
        """
    def release_frame(self, frame: SensorFrame) -> None:
        """
                Release sensor frame.
        
                :param frame: Handle of frame to be released.
                :raises EdgeAppError:
        """
    @property
    def handle(self) -> int:
        ...
def format_timestamp(timestamp: int) -> str:
    """
    Format timestamp into string representation
    """
def get_file_suffix(dataType: DataExportDataType) -> str:
    """
    Get file suffix for data export
    """
def get_last_error_string(param: EdgeAppLibSensorStatusParam) -> str:
    """
    Get the last error string from the sensor
    """
def get_port_settings() -> str:
    """
    Get port settings as JSON string
    """
def get_workspace_directory() -> str:
    """
    Get the workspace directory
    """
def run_sm(edge_app_class: type, stream_key: str | None = None) -> int:
    """
               Run the Edge App state machine. Blocks until the edge app is destroyed.
    
               :param edge_app_class: Class that implements the edge app event functions.
               :param stream_key: Key of the stream to open in the edge app.
               :return: Edge app exit code.
    """
def send_file(dataType: DataExportDataType, filePath: str, url: str, timeout_ms: int) -> DataExportResult:
    """
    Send file to the cloud synchronously
    """
def send_input_tensor(frame: SensorFrame) -> None:
    """
              Sends the Input Tensor to the cloud synchronously.
    
              This function sends the input tensor data from the provided frame to the
              cloud.
    """
def send_metadata(frame: SensorFrame) -> None:
    """
              Sends the Metadata to the cloud synchronously.
    
              This function sends the post-processed output tensor (metadata) from the
              provided sensor frame to the cloud.
    """
def send_state(topic: str, state: str) -> DataExportResult:
    """
    Send state to the cloud synchronously
    """
def send_telemetry(data: bytes, timeout_ms: int) -> DataExportResult:
    """
    Send telemetry to the cloud synchronously
    """
@typing.overload
def stream() -> SensorStream:
    """
    Gets the current sensor stream.
    """
@typing.overload
def stream() -> SensorStream:
    """
    Gets the current sensor stream.
    """
AI_MODEL_BUNDLE_ID_SIZE: int = 128
Aborted: ResponseCode  # value = <ResponseCode.Aborted: 10>
AlreadyExists: ResponseCode  # value = <ResponseCode.AlreadyExists: 6>
Base64: SendDataType  # value = <SendDataType.Base64: 0>
Cancelled: ResponseCode  # value = <ResponseCode.Cancelled: 1>
DataLoss: ResponseCode  # value = <ResponseCode.DataLoss: 15>
DataTooLarge: DataExportResult  # value = <DataExportResult.DataTooLarge: 4>
DeadlineExceeded: ResponseCode  # value = <ResponseCode.DeadlineExceeded: 4>
Denied: DataExportResult  # value = <DataExportResult.Denied: 5>
ERROR: DataExportResult  # value = <DataExportResult.ERROR: 1>
Enqueued: DataExportResult  # value = <DataExportResult.Enqueued: 6>
FailedPrecondition: ResponseCode  # value = <ResponseCode.FailedPrecondition: 9>
Internal: ResponseCode  # value = <ResponseCode.Internal: 13>
InvalidArgument: ResponseCode  # value = <ResponseCode.InvalidArgument: 3>
InvalidParam: DataExportResult  # value = <DataExportResult.InvalidParam: 3>
Json: SendDataType  # value = <SendDataType.Json: 1>
MESSAGE: EdgeAppLibSensorStatusParam  # value = <EdgeAppLibSensorStatusParam.MESSAGE: 0>
Metadata: DataExportDataType  # value = <DataExportDataType.Metadata: 1>
NotFound: ResponseCode  # value = <ResponseCode.NotFound: 5>
Ok: ResponseCode  # value = <ResponseCode.Ok: 0>
OutOfRange: ResponseCode  # value = <ResponseCode.OutOfRange: 11>
PermissionDenied: ResponseCode  # value = <ResponseCode.PermissionDenied: 7>
Raw: DataExportDataType  # value = <DataExportDataType.Raw: 0>
ResourceExhausted: ResponseCode  # value = <ResponseCode.ResourceExhausted: 8>
SUCCESS: DataExportResult  # value = <DataExportResult.SUCCESS: 0>
TRACE: EdgeAppLibSensorStatusParam  # value = <EdgeAppLibSensorStatusParam.TRACE: 2>
Timeout: DataExportResult  # value = <DataExportResult.Timeout: 2>
Unauthenticated: ResponseCode  # value = <ResponseCode.Unauthenticated: 16>
Unavailable: ResponseCode  # value = <ResponseCode.Unavailable: 14>
Unimplemented: ResponseCode  # value = <ResponseCode.Unimplemented: 12>
Uninitialized: DataExportResult  # value = <DataExportResult.Uninitialized: 7>
Unknown: ResponseCode  # value = <ResponseCode.Unknown: 2>
